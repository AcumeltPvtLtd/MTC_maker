"""
core/sheets_client.py
=====================
Handles interaction with Google Sheets API.
1. Authenticates using the JSON key file defined in config.
2. Checks for duplicates using 'gen_id' (Column C).
3. Maps data dictionary to specific cells based on config.SHEET_COLUMNS.
4. Uploads data safely with retry logic.
"""

import gspread
import time
from google.oauth2.service_account import Credentials
import config
from core import utils

class GoogleSheetsClient:
    def __init__(self):
        self.client = None
        self.sheet = None
        self.worksheet = None
        self._authenticate()

    def _authenticate(self):
        """Authenticates using the JSON file path from config."""
        try:
            utils.logger.info("Connecting to Google Sheets...")
            
            # verify file exists
            if not config.CREDENTIALS_PATH.exists():
                raise FileNotFoundError(f"JSON Key not found at: {config.CREDENTIALS_PATH}")

            # Load credentials from the JSON file
            creds = Credentials.from_service_account_file(
                config.CREDENTIALS_PATH, 
                scopes=config.SCOPES
            )
            
            self.client = gspread.authorize(creds)
            
            # Open Spreadsheet and Worksheet
            self.sheet = self.client.open_by_key(config.SPREADSHEET_ID)
            self.worksheet = self.sheet.worksheet(config.WORKSHEET_NAME)
            
            utils.logger.info(f"Connected to: {self.sheet.title} / {self.worksheet.title}")
            
        except Exception as e:
            utils.logger.error(f"Google Auth Failed: {e}")
            raise

    def _get_existing_ids(self):
        """
        Fetches all 'gen_id's from Column C to prevent duplicates.
        Returns a set of existing IDs (e.g., {'F346-B1', 'F346-F2'}).
        """
        try:
            # config.SHEET_COLUMNS['gen_id'] is 2 (0-based)
            # gspread uses 1-based indexing, so we add 1.
            col_index = config.SHEET_COLUMNS['gen_id'] + 1
            
            # specific optimization: only fetch that one column
            existing_ids = self.worksheet.col_values(col_index)
            
            # Return as set for instant lookup
            return set(existing_ids)
        except Exception as e:
            utils.logger.error(f"Failed to fetch existing IDs: {e}")
            return set()

    def upload_data(self, data_list):
        """
        Main function to upload data.
        Args:
            data_list (list): List of dictionaries from excel_parser.
        """
        if not data_list:
            return

        try:
            # 1. Get Existing Data to avoid duplicates
            existing_ids = self._get_existing_ids()
            rows_to_append = []

            for record in data_list:
                unique_id = record.get('gen_id')
                
                # Check Duplicate
                if unique_id in existing_ids:
                    utils.logger.info(f"Skipping Duplicate: {unique_id}")
                    continue

                # 2. Prepare Row List (Initialize with empty strings)
                # We create a list long enough to hold our max column index (Column O/S is around index 18)
                row = [''] * 25 
                
                # 3. Map Metadata using config indices
                row[config.SHEET_COLUMNS['heat']] = record.get('heat_number', '')
                row[config.SHEET_COLUMNS['grade']] = record.get('grade', '')
                row[config.SHEET_COLUMNS['gen_id']] = unique_id
                row[config.SHEET_COLUMNS['stage_code']] = record.get('stage_code', '')
                
                # 4. Map Chemicals
                # Loop through config keys ('h', 'i', 'j', etc.)
                for key, sheet_col_idx in config.SHEET_COLUMNS.items():
                    # We only care about single letter keys that exist in parsed data
                    if key in record and len(key) <= 2: 
                        val = record.get(key)
                        row[sheet_col_idx] = val

                rows_to_append.append(row)
                utils.logger.info(f"Queued for Upload: {unique_id}")

            # 5. Batch Append
            if rows_to_append:
                self._safe_append(rows_to_append)
            else:
                utils.logger.info("No new unique data to upload.")

        except Exception as e:
            utils.logger.error(f"Upload flow failed: {e}")

    def _safe_append(self, rows):
        """Appends rows with Retry Logic."""
        for attempt in range(config.API_MAX_RETRIES):
            try:
                # value_input_option='USER_ENTERED' ensures numbers are stored as numbers, not text
                self.worksheet.append_rows(rows, value_input_option='USER_ENTERED')
                utils.logger.info(f"Successfully uploaded {len(rows)} rows to Google Sheets.")
                return
            except Exception as e:
                utils.logger.warning(f"API Error (Attempt {attempt+1}): {e}")
                time.sleep(config.API_RETRY_DELAY)
        
        utils.logger.error("Upload failed after max retries.")

# =========================================
# SELF-TEST BLOCK
# =========================================
if __name__ == "__main__":
    print("--- Testing Google Sheets Client ---")
    
    # 1. Initialize Client
    try:
        client = GoogleSheetsClient()
        
        # 2. Create Dummy Data
        # We use a timestamp to make sure the ID is unique every time we run the test
        unique_test_id = f"TEST-{int(time.time())}"
        
        test_data = [{
            'heat_number': 'TEST-HEAT',
            'grade': 'TEST-GRADE',
            'gen_id': unique_test_id,
            'stage_code': 'T1',
            'h': 1.11,
            'i': 2.22,
            'j': 3.33,
            'l': 0.05,
            'o': 0.01
        }]
        
        print(f"Attempting to upload ID: {unique_test_id}")
        
        # 3. Upload
        client.upload_data(test_data)
        
        print("\n✅ Test Complete. Please check your Google Sheet row at the bottom.")
        
    except Exception as e:
        print(f"\n❌ Test Failed: {e}")